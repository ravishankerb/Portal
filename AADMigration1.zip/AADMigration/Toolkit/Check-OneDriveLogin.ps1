﻿# Define the log file path
$logFilePath = "C:\Development\Scripts\OneDriveStatusLog.txt"

# Function to log messages
function Write-Log {
    param (
        [string]$message
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "$timestamp - $message"
    Add-Content -Path $logFilePath -Value $logMessage
}

# Function to check if user is logged into OneDrive
function Is-OneDriveLoggedIn {
    # Check if OneDrive process is running
    $oneDriveProcess = Get-Process -Name "OneDrive" -ErrorAction SilentlyContinue
    if ($oneDriveProcess) {
        # Check the OneDrive status using registry key
        $oneDriveStatus = Get-ItemProperty -Path "HKCU:\Software\Microsoft\OneDrive" -Name "UserSID" -ErrorAction SilentlyContinue
        if ($oneDriveStatus) {
            return $true
        }
    }
    return $false
}

# Main script logic
while ($true) {
    if (Is-OneDriveLoggedIn) {
        Write-Log "User is logged into OneDrive."
    } else {
        Write-Log "User is not logged into OneDrive."
    }
    
    # Sleep for a specified interval (e.g., 5 minutes) before checking again
    Start-Sleep -Seconds 300
}
